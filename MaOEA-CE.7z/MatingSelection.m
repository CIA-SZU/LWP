function MatingPool = MatingSelection(PopObj,LP,z,znad,Rank,FrontNo)

	%% normalization of the Population
    [N,M]=size(PopObj);
    PopObj = (PopObj-repmat(z,size(PopObj,1),1))./repmat(znad-z ,size(PopObj,1),1);             
      
	%% calculate the I?+(x, y) value of each two individuals 
    d=Distribute_Calculate(PopObj,LP);  
    d(logical(eye(N))) = +inf;
    d  = sort(d,2);
    
    %% calculate the density of each solution 
    dk = 1./(sum(d(:,1:ceil(end*0.1)),2)+1);
         
	%% Binary tournament selection
	MatingPool = TournamentSelection(2,size(PopObj,1),Rank,dk');
   
end

%% �����֮����С����D
function [D]=Distribute_Calculate(PopObj,Lp)
    if Lp>1
        D = pdist2(PopObj,PopObj,'cosine');
    elseif Lp==1
        PopObj=PopObj./repmat(sum(PopObj,2),1,size(PopObj,2));     
        D = pdist2(PopObj,PopObj,'euclidean');
    else
        PopObj = 1- PopObj;
        D = pdist2(PopObj,PopObj,'cosine');
    end    
end